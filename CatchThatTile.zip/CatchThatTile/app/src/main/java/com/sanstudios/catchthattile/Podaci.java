package com.example.sran.kotlinprviprojekat;

public class Podaci {

    private int classicEasy,classicNormal,classicHard;
    private int skillEasy,skillNormal,skillHard;
    private int timeEasy60,timeEasy120,timeEasy180,timeEasy240;
    private int timeNormal60,timeNormal120,timeNormal180,timeNormal240;
    private int timeHard60,timeHard120,timeHard180,timehard240;

    public int getClassicEasy() {
        return classicEasy;
    }

    public void setClassicEasy(int classicEasy) {
        if (classicEasy > this.classicEasy)
            this.classicEasy = classicEasy;
    }

    public int getClassicNormal() {
        return classicNormal;
    }

    public void setClassicNormal(int classicNormal) {
        if (classicNormal > this.classicNormal)
            this.classicNormal = classicNormal;
    }

    public int getClassicHard() {
        return classicHard;
    }

    public void setClassicHard(int classicHard) {
        if (classicHard > this.classicHard)
            this.classicHard = classicHard;
    }

    public int getSkillEasy() {
        return skillEasy;
    }

    public void setSkillEasy(int skillEasy) {
        if (skillEasy > this.skillEasy)
            this.skillEasy = skillEasy;
    }

    public int getSkillNormal() {
        return skillNormal;
    }

    public void setSkillNormal(int skillNormal) {
        if (skillNormal > this.skillNormal)
            this.skillNormal = skillNormal;
    }

    public int getSkillHard() {
        return skillHard;
    }

    public void setSkillHard(int skillHard) {
        if (skillHard > this.skillHard)
            this.skillHard = skillHard;
    }

    public int getTimeEasy60() {
        return timeEasy60;
    }

    public void setTimeEasy60(int timeEasy60) {
        if (timeEasy60 > this.timeEasy60)
            this.timeEasy60 = timeEasy60;
    }

    public int getTimeEasy120() {
        return timeEasy120;
    }

    public void setTimeEasy120(int timeEasy120) {
        if (timeEasy120 > this.timeEasy120)
            this.timeEasy120 = timeEasy120;
    }

    public int getTimeEasy180() {
        return timeEasy180;
    }

    public void setTimeEasy180(int timeEasy180) {
        if (timeEasy180 > this.timeEasy180)
            this.timeEasy180 = timeEasy180;
    }

    public int getTimeEasy240() {
        return timeEasy240;
    }

    public void setTimeEasy240(int timeEasy240) {
        if (timeEasy240 > this.timeEasy240)
            this.timeEasy240 = timeEasy240;
    }

    public int getTimeNormal60() {
        return timeNormal60;
    }

    public void setTimeNormal60(int timeNormal60) {
        if (timeNormal60 > this.timeNormal60)
            this.timeNormal60 = timeNormal60;
    }

    public int getTimeNormal120() {
        return timeNormal120;
    }

    public void setTimeNormal120(int timeNormal120) {
        if (timeNormal120 > this.timeNormal120)
            this.timeNormal120 = timeNormal120;
    }

    public int getTimeNormal180() {
        return timeNormal180;
    }

    public void setTimeNormal180(int timeNormal180) {
        if (timeNormal180 > this.timeNormal180)
            this.timeNormal180 = timeNormal180;
    }

    public int getTimeNormal240() {
        return timeNormal240;
    }

    public void setTimeNormal240(int timeNormal240) {
        if (timeNormal240 > this.timeNormal240)
            this.timeNormal240 = timeNormal240;
    }

    public int getTimeHard60() {
        return timeHard60;
    }

    public void setTimeHard60(int timeHard60) {
        if (timeHard60 > this.timeHard60)
            this.timeHard60 = timeHard60;
    }

    public int getTimeHard120() {
        return timeHard120;
    }

    public void setTimeHard120(int timeHard120) {
        if (timeHard120 > this.timeHard120)
            this.timeHard120 = timeHard120;
    }

    public int getTimeHard180() {
        return timeHard180;
    }

    public void setTimeHard180(int timeHard180) {
        if (timeHard180 > this.timeHard180)
            this.timeHard180 = timeHard180;
    }

    public int getTimehard240() {
        return timehard240;
    }

    public void setTimehard240(int timehard240) {
        if (timehard240 > this.timehard240)
            this.timehard240 = timehard240;
    }
}
