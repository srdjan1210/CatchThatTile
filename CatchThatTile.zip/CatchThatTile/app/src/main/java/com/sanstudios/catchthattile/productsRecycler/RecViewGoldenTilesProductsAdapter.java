package com.sanstudios.catchthattile.productsRecycler;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;


import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.sanstudios.catchthattile.R;

import java.util.ArrayList;

public class RecViewGoldenTilesProductsAdapter extends RecyclerView.Adapter<RecViewGoldenTilesProductsHolder> {

    private Context ctx;
    private ArrayList<Double> priceList;
    private ArrayList<Integer> tileQuantity;


    public RecViewGoldenTilesProductsAdapter(Context ctx, ArrayList<Double> priceList, ArrayList<Integer> tileQuantity ){

        this.ctx = ctx;
        this.priceList = priceList;
        this.tileQuantity = tileQuantity;

    }
    @NonNull
    @Override
    public RecViewGoldenTilesProductsHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new RecViewGoldenTilesProductsHolder(LayoutInflater.from(ctx).inflate(R.layout.products_item,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull RecViewGoldenTilesProductsHolder holder, int position) {
        holder.productName.setText(tileQuantity.get(position).toString()+" GT");
        holder.productPrice.setText(priceList.get(position).toString()+"$");
    }

    @Override
    public int getItemCount() {
        return priceList.size();
    }
}
